module.exports = {
  important_variables : [
    "version",
    "prefix",
    "log_guild",
    "complete_log_channel",
    "event_log_channel",
    "dm_dump_channel",
    "dm_engine",
    "log_enabled",
    "obey_bans"
  ] 
}